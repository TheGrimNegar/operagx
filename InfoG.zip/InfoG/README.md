# InfoG v2.0
InfoG (it's Info-jee) is an information gathering tool. You can find ip addresses, phone number details and much more.


**How to use:**

First clone the repository:\
**git clone https://github.com/Tech-Sec/InfoG.git**

Change your directory to InfoG  folder:\
**cd InfoG**

Then type:\
**pip install -r requirements.txt**

After that, type:\
**python3 InfoG.py**

![](IMG_1.JPG)


Option 1 will give you the ip address of the domain name you type.\
(Don't type the domain name with the protocol. eg: ~~https://google.com~~, instead type: www.google.com

Option 2 gives you the country name, city, gps coordinates and much more about an ip address.

Option 3 just gives you the country and service provider of aa specific mobile number.\
Enter yor phone number with the country code. eg: +1xxxxxxxxxxxx

Option 4 will give you a lure link with which you can get the ip address of the target once he/she opens it.

**New Feature in v2.0**\
IP-Grabber by ![Krishna Pranav](https://github.com/krishpranav/IP-Grabber)

Now you can grab the ip address of your target by sending him a lure link. You can get the ip address, browser details etc. 

**Note**\
IP-Grabber is only available on non-Windows platform. For more deatails check ![/IP-Grabber/README.md](/IP-Grabber/README.md)

**Versions:**\
**![v1.0](https://github.com/Tech-Sec/InfoG/archive/v1.0.zip)**


**FOR EDUCATIONAL PURPOSES ONLY**
