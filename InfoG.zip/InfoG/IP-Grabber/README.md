# IP-Grabber
This tool will grab the ip address of a person when he opens the link

# Steps to run this tool on linux:
- git clone https://github.com/krishpranav/IP-Grabber
- cd IP-Grabber
- sudo chmod 777 *
- bash ip-grabber.sh

# Steps to run this tool on mac:
- git clone https://github.com/krishpranav/IP-Grabber
- cd IP-Grabber
- sudo chmod 777 *
- bash ip-grabber.sh

# Steps to run this tool on termux(android):
- apt update
- pkg update
- pkg install git
- git clone https://github.com/krishpranav/IP-Grabber
- cd IP-Grabber
- chmod +x *
- bash ip-grabber.sh

 ### after the victim opens the link you will get the ip of the victim you want to wait for 20 to 30 sec to get the full info of the particular ip
    
    NOTE: login.html has take from  https://github.com/kinghacker0/Black-Water/blob/master/sites/create/login.html
    
    TOOL IS CREATED BY KRISNA PRANAV
     
